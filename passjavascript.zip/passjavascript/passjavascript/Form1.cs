﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace passjavascript
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitBrowser();
        }
        public async void InitBrowser()
        {
            await initizated();
            webView21.CoreWebView2.Navigate("https://www.youtube.com/");
        }
        private async Task initizated()
        {
            await webView21.EnsureCoreWebView2Async(null);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addmessage();
        }
        public async void addmessage()
        {
            await webView21.ExecuteScriptAsync("document.getElementById('logo-icon').hidden=true");
            await webView21.ExecuteScriptAsync("alert('hi, i am hidden the logo using javascript')");
        }
        
    }
}
